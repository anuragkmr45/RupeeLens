# PLANS.md

Use this template before implementing any multi-step, cross-module, or risky change.

## Title
Short, explicit name of the task.

## Goal
What user or system outcome should change?

## Context
Relevant tickets, docs, modules, bugs, or constraints.

## Assumptions
List assumptions being made. Mark anything that should be validated before coding.

## Files / modules likely to change
- `apps/...`
- `packages/...`
- `docs/...`

## API / schema impact
- New endpoint?
- Schema change?
- Migration?
- Backward compatibility concerns?

## Implementation steps
1. 
2. 
3. 

## Tests to add or update
- unit
- integration
- E2E
- fixtures

## Rollout / flag plan
- feature flag?
- config toggle?
- kill switch?
- migration ordering?

## Risks
- data loss?
- parser regressions?
- performance?
- privacy/security?

## Done when
Concrete acceptance criteria.