# UPI Spend Tracker v1 Planning Pack

Date: 2026-03-13

This planning pack turns the product idea into an execution-ready repo documentation set for an agile team and AI coding agents.

## Included files

- `AGENTS.md` — repo-level guidance for Codex and contributors
- `PLANS.md` — execution-plan template for complex tasks
- `docs/01_PRD.md` — product requirements document
- `docs/02_Engineering_Design.md` — architecture and implementation design
- `docs/03_Screen_Spec.md` — screen and UX flow specification
- `docs/04_API_Contract.yaml` — OpenAPI contract for backend services
- `docs/05_Backlog.md` — descriptive epics and tickets
- `docs/05_Backlog.csv` — import-friendly ticket sheet
- `docs/06_Release_Plan.md` — sprint map, readiness, and delivery governance

## Recommended usage

1. Product/design align on `01_PRD.md` and `03_Screen_Spec.md`.
2. Engineering aligns on `02_Engineering_Design.md`.
3. Backend/mobile generate implementation tasks from `04_API_Contract.yaml`.
4. Delivery manager imports `05_Backlog.csv` into Linear/Jira.
5. Repo root keeps `AGENTS.md` so Codex reads project instructions automatically.
6. For major tasks, create a plan using `PLANS.md` before coding.

## Notes

- The pack assumes Android-first full functionality and iOS companion/manual mode later.
- The pack is intentionally local-first and avoids paid third-party product APIs in v1.
- It is written to be understandable by humans and coding agents with minimal ambiguity.